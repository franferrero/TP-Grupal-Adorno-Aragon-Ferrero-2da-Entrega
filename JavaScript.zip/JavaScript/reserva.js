document.addEventListener("DOMContentLoaded", function() {
    formReserva = document.getElementById("form-reserva");
    botonSubmit = document.querySelector("button[type='submit']");
    botonCancelar = document.querySelector("button[type='button']");
    reservaRealizada = false;

    formReserva.addEventListener("submit", function(event) {
        event.preventDefault(); 
        if (formReserva.checkValidity()) {
            if (reservaRealizada) {
                alert("¡Ya hiciste una reserva, para realizar una nueva reserva cancela la anterior!");  
            } else {
                alert("¡Reserva realizada!");
                reservaRealizada = true; 
                formReserva.reset(); 
            }
        }
    });

   
    botonCancelar.addEventListener("click", function() {
        if (reservaRealizada) {
            alert("La reserva ha sido cancelada.");
            reservaRealizada = false;
        } else {
            alert("No se puede cancelar, ya que no hay una reserva hecha.");
        }
    });
});
