document.addEventListener("DOMContentLoaded", function() {
    form = document.getElementById("contactForm");

    form.addEventListener("submit", function(event) {
        if (form.checkValidity()) {
            alert("¡Mensaje enviado!");
            form.reset(); 
        }
    });
});
